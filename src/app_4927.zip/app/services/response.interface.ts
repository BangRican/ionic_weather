export interface WeatherResponse {
    name: string;
    main: {
        temp:number
    }
}